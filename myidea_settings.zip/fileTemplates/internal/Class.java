#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
 * @class ${NAME}
 * @Author ${USER}
 * @Description //TODO 
 * @Date  ${DATE} ${TIME}
 * @Version 1.0
*/
public class ${NAME} {
}
